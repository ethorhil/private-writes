Even with encrypted payloads, systems leak information through timing, pool flows, bridging patterns, and fee payments.
**Categories:** [[6 Cross-Pattern Problems#^3cb481|Privacy Leakage & Anonymity]]
