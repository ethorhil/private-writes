Provers, relayers, and DA committees often lack durable incentive structures.
**Categories:** [[6 Cross-Pattern Problems#^c14e56|Governance & Operational Risk]]
