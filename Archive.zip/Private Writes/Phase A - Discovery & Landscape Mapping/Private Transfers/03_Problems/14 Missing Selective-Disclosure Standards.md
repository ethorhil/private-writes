There is no widely adopted framework for proofs-of-innocence, attribute-based disclosures, or auditability.
**Categories:** [[6 Cross-Pattern Problems#^c4ed15|Compliance & Selective Disclosure]]
