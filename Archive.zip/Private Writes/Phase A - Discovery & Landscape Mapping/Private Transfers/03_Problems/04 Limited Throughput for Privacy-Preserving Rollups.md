Proof generation and DA bottlenecks restrict achievable throughput compared to non-private L2s.
**Categories:** [[6 Cross-Pattern Problems#^645ab1|Data Availability, Scalability & Exits]]
