Validium and Plasma variants rely on DA committees or centralized operators, creating withholding and censorship risks.
**Categories:** [[6 Cross-Pattern Problems#^c14e56|Governance & Operational Risk]]; [[6 Cross-Pattern Problems#^645ab1|Data Availability, Scalability & Exits]]
