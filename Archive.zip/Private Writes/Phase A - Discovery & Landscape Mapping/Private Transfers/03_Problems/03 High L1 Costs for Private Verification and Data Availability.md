Proof verification, calldata posting, and DA constraints create high L1 gas costs and limit TPS.
**Categories:** [[6 Cross-Pattern Problems#^645ab1|Data Availability, Scalability & Exits]]
