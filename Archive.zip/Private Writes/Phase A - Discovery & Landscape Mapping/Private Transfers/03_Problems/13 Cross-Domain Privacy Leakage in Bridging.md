Bridge contracts, wrappers, and exit routines expose linkages when moving private assets between L1 and L2 domains.
**Categories:** [[6 Cross-Pattern Problems#^e74e59|Composability & Interoperability]]; [[6 Cross-Pattern Problems#^3cb481|Privacy Leakage & Anonymity]]
