Price impact, liquidation mechanics, and visible execution paths reveal private user behavior and balances.
**Categories:** [[6 Cross-Pattern Problems#^3cb481|Privacy Leakage & Anonymity]]
