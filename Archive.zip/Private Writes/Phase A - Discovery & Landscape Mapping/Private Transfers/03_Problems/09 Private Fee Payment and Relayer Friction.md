Relayer reliance, gas abstraction, and fee-payment flows often reintroduce linkability or UX complexity.
**Categories:** [[6 Cross-Pattern Problems#^be95db|UX & Developer Experience]]
