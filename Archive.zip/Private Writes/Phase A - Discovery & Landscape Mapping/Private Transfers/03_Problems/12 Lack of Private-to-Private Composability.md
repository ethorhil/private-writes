Most systems cannot support private contract calls across applications without collapsing privacy boundaries.
**Categories:** [[6 Cross-Pattern Problems#^e74e59|Composability & Interoperability]]
