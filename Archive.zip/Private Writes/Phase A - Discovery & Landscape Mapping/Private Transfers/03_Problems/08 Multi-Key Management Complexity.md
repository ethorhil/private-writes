Users must manage spending, viewing, auditing, and recovery keys, with significant failure modes.
**Categories:** [[6 Cross-Pattern Problems#^be95db|UX & Developer Experience]]; [[6 Cross-Pattern Problems#^3cb481|Privacy Leakage & Anonymity]]
