Compliance-compatible designs (e.g., AML-aligned privacy) remain early-stage and inconsistent across mechanisms.
**Categories:** [[6 Cross-Pattern Problems#^c4ed15|Compliance & Selective Disclosure]]
