Users and liquidity are distributed across isolated pools and chains, reducing effective anonymity.
**Categories:** [[6 Cross-Pattern Problems#^3cb481|Privacy Leakage & Anonymity]]; [[6 Cross-Pattern Problems#^e74e59|Composability & Interoperability]]
