Systems requiring identity or membership struggle to prevent correlation across contexts.
**Categories:** [[6 Cross-Pattern Problems#^c4ed15|Compliance & Selective Disclosure]]; [[6 Cross-Pattern Problems#^3cb481|Privacy Leakage & Anonymity]]
