Mempool interactions, P2P timing, and routing metadata leak user correlations outside the cryptographic layer.
**Categories:** [[6 Cross-Pattern Problems#^3cb481|Privacy Leakage & Anonymity]]; [[6 Cross-Pattern Problems#^be95db|UX & Developer Experience]]
