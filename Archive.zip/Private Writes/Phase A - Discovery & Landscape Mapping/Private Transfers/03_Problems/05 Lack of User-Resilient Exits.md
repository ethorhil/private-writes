When DA providers fail or censor, users of DA-light systems cannot reconstruct private state or exit safely.
**Categories:** [[6 Cross-Pattern Problems#^645ab1|Data Availability, Scalability & Exits]]; [[6 Cross-Pattern Problems#^c14e56|Governance & Operational Risk]]
