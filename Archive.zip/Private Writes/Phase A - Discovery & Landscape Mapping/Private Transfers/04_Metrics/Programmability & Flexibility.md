– Range and expressiveness of private logic: from simple payment flows to rich private smart-contract ecosystems.
