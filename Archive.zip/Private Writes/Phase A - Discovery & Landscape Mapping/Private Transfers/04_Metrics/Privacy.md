– Strength of transactional privacy at the state level (sender/receiver/amount shielding, linkability, metadata exposure).
