– Typical on-chain cost per transfer, including proof verification and calldata.
