– Realistic throughput potential, considering cryptographic overhead and DA constraints, not just raw block limits.
