– Operational burden on users: keys, notes, relayers, exits, onboarding.
– Higher scores correspond to simpler, more robust UX in practice.
