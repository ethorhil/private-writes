![[Appendix A — Pattern Definition Cards#<6. Private Plasma>]]
