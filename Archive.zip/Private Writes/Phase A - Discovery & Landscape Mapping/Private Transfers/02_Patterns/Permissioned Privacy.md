![[Appendix A — Pattern Definition Cards#<4. Permissioned Privacy>]]
