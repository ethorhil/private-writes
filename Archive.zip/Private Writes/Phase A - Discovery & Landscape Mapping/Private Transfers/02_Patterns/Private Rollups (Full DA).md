![[Appendix A — Pattern Definition Cards#<5. Private Rollups (Full DA)>]]
