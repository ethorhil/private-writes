![[Appendix A — Pattern Definition Cards#<2. L1 Shielded Pools>]]
