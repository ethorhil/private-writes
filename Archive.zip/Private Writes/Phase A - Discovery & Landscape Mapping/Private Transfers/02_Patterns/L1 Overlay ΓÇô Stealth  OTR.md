![[Appendix A — Pattern Definition Cards#<1. L1 Overlay – Stealth OTR>]]

