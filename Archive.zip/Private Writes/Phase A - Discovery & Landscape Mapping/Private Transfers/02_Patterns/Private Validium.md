![[Appendix A — Pattern Definition Cards#<7. Private Validium>]]
